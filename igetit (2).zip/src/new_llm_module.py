# === llm_module.py ===
import os
import logging
from dotenv import load_dotenv
from typing import List
from langchain.schema import Document
from langchain.prompts import ChatPromptTemplate
from langchain.schema.runnable import RunnableMap
from langchain_openai import AzureChatOpenAI
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from azure.core.pipeline.transport import RequestsTransport

# Load environment variables
load_dotenv()

AZURE_LLM_DEPLOYMENT = os.getenv("AZURE_LLM_DEPLOYMENT")
AZURE_LLM_API_VERSION = os.getenv("AZURE_LLM_API_VERSION")
AZURE_LLM_OPENAI_ENDPOINT = os.getenv("AZURE_LLM_OPENAI_ENDPOINT")
AZURE_LLM_OPENAI_API_KEY = os.getenv("AZURE_LLM_OPENAI_API_KEY")
AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT")
AZURE_SEARCH_KEY = os.getenv("AZURE_SEARCH_KEY")

from constants import INDEX_NAME
AZURE_SEARCH_INDEX = INDEX_NAME

transport = RequestsTransport(connection_verify=False)

# === Prompt Template ===
TEMPLATE = """
You are a helpful, friendly assistant for the IGETIT learning platform.

Your primary goal is to help users access learning materials and answer questions based on the provided internal documents, which may include video transcripts, course files, and URLs.

---

### Step 1: Detect Greeting vs. Learning Query

- If the user message is a **greeting or small talk** (e.g., "hi", "hello there", "how are you", "good evening", etc.), respond in a **warm, conversational tone**.
- Randomly choose a response from the Greeting Responses section below.
- Do **not** include course content or context references when replying to greetings.

- If the user’s message is a **learning-related question**, proceed to Step 2.

---

### Step 2: Answering Learning Questions

- Use the extracted context and prior conversation history to answer the user's question.
- Always include the **source** (document name, video file name, or URL). If the answer comes from a video transcript (.mp4), include the **exact timestamp(s)**.
- If multiple relevant sources or timestamps exist, summarize the best answer and list all related sources and timestamps.

- If the answer is only **partially supported** by the internal documents:
  - Still respond with the most helpful, relevant answer.
  - Aim to keep the conversation supportive and continuous, even if the context is limited.
  - Instead, **naturally offer to help further** — for example:
    - Suggest continuing the conversation.
    - Offer to explore the topic from another tool or angle.
    - Prompt gently with a phrase like:
      - “Let me know if you’d like to explore this further.”
      - “Happy to dive deeper or look at this another way if you’d like.”
      - “Would you like to see how this applies in another setting?”

- If no relevant answer is found, respond with:

🌐 Internal docs are not sufficient to answer the query, Running web search...

- Do **not fabricate answers** or include information not found in the context.

---

### Greeting Responses (rotate or choose naturally):

1. "Hi there! I'm doing well—thanks for asking 😊 Let me know how I can help with your learning today."
2. "Hello! 👋 If you need assistance with course materials or have any doubts while learning, I’m here to help."
3. "Hey! Nice to see you. Feel free to ask if you're stuck on something or want help navigating a course."
4. "Good day! Let me know if there’s anything I can assist you with regarding your courses."
5. "Hi! I'm here to support you through your learning journey on IGETIT. What would you like to explore today?"
6. "Hey there! 😊 Ready to dive into some learning? Ask me anything, I’ve got your back!"

---

Only provide responses that match the user’s intent (greeting vs. question). Be natural, concise, and supportive.

CONTEXT:
---------
{context}

CHAT HISTORY:
-------------
{chat_history}

QUESTION:
---------
{question}

Helpful Answer (always include source; include timestamp if from video files):

"""

prompt = ChatPromptTemplate.from_template(TEMPLATE)

# === LLM Initialization ===
def initialize_llm():
    logging.info("Initializing Azure Chat OpenAI")
    return AzureChatOpenAI(
        azure_deployment=AZURE_LLM_DEPLOYMENT,
        api_version=AZURE_LLM_API_VERSION,
        temperature=0,
        max_tokens=None,
        timeout=None,
        max_retries=2,
        azure_endpoint=AZURE_LLM_OPENAI_ENDPOINT,
        api_key=AZURE_LLM_OPENAI_API_KEY,
        streaming=True,
        callbacks=[StreamingStdOutCallbackHandler()],
    )

# === Azure Cognitive Search ===
def initialize_search_client():
    return SearchClient(
        endpoint=AZURE_SEARCH_ENDPOINT,
        index_name=AZURE_SEARCH_INDEX,
        credential=AzureKeyCredential(AZURE_SEARCH_KEY),
        transport=transport,
    )

def get_relevant_documents(query: str, top_k: int = 5) -> List[Document]:
    try:
        client: SearchClient = initialize_search_client()
        results = client.search(query, top=top_k, select=["content", "source"])

        documents = []
        for result in results:
            content = result.get("content", "")
            source = result.get("source", "azure-search")
            if content:
                documents.append(
                    Document(page_content=content, metadata={"source": source})
                )
        return documents

    except Exception as e:
        print(f"❌ Error in get_relevant_documents: {e}")
        return []

def format_docs(docs: List[Document]) -> str:
    return "\n\n".join(
        [
            f"Content: {doc.page_content}\nSource: {doc.metadata.get('source', 'No source provided')}"
            for doc in docs
        ]
    )

# === Full RAG Chain (context + chat history) ===
def build_rag_chain(llm):
    return (
        RunnableMap(
            {
                "context": lambda inputs: format_docs(
                    get_relevant_documents(inputs["question"])
                ),
                "chat_history": lambda inputs: inputs.get("chat_history", ""),
                "question": lambda inputs: inputs["question"],
            }
        )
        | prompt
        | llm
    )

# === History-Only Chain (empty context) ===
def build_history_only_chain(llm):
    return (
        RunnableMap(
            {
                "context": lambda inputs: "",  # <- No internal docs used
                "chat_history": lambda inputs: inputs.get("chat_history", ""),
                "question": lambda inputs: inputs["question"],
            }
        )
        | prompt
        | llm
    )
